package com.bt.poc.serviceImpl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.bt.poc.service.SpringBootWithAngularPoCService;
import com.google.common.io.Files;

@Service
public class SpringBootWithAngularPoCServiceImpl implements SpringBootWithAngularPoCService {

	@Override
	public void uploadFile(MultipartFile file) {
		// TODO Auto-generated method stub
		System.out.println("hello");
		try {
			
		//	AccessController.checkPermission(new FilePermission("C:/Users/613128207/Documents/workspace/Uploads", "read,write"));
			File src=new File(file.getOriginalFilename());
			System.out.println(src.getAbsolutePath());
			System.out.println(src.getPath());
			System.out.println("original file name is" +src);
			src.createNewFile();
			src.setReadable(true);
			src.setExecutable(true);
	 
			FileOutputStream outStream=new FileOutputStream(src);
			//System.out.println(outStream);
			outStream.write(file.getBytes());
			outStream.close();
			//file srcFile=new File()
			//System.out.println(src.getAbsolutePath());
			File dest=new File("C:\\Users\\613128~1\\AppData\\Local\\Temp");
		
		    dest.setWritable(true);
		    dest.setExecutable(true);
			Files.copy(src,dest);
		} 
		catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (SecurityException e) {
            System.out.println("failure :(");
            
        }
	
		
		/*try {
			file.transferTo(dest);
		} 
		catch (IllegalStateException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}
	
	/*@Override
	public void uploadFile(FileModel file) {
		// TODO Auto-generated method stub
		
		File source=new File(file.getPath());
		File dest=new File("C:/Users/613128207/Desktop/Uploads");
		try {
			FileUtils.copyFileToDirectory(source, dest);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}*/
 
}

package com.bt.poc.service;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public interface SpringBootWithAngularPoCService {
	
	void uploadFile(MultipartFile file);
	
	
	

}

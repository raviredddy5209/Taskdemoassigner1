package com.bt.poc.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.bt.poc.service.SpringBootWithAngularPoCService;

@RestController
@RequestMapping("/bt/poc")
public class SpringBootWithAngularPoCController {
	
	@Autowired
	private SpringBootWithAngularPoCService springBootWithAngularPoCService;
	
	//FileModel file=new FileModel();
		
	@PostMapping("/uploadFile")
	public ResponseEntity<String> postFile(@RequestParam("file") MultipartFile file){
		System.out.println("hii");
		springBootWithAngularPoCService.uploadFile(file);
		return new ResponseEntity<String>("success", new HttpHeaders(), HttpStatus.CREATED);
		
	}
	
		
	

}
